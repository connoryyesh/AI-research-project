import React from 'react';

const Survey = () => {
  return (
    <div className="container" style={{ textAlign: 'center' }}>
      <h2>Survey</h2>
      <p>
        This is the survey page. Here, questions from the survey builder will be displayed.
      </p>
    </div>
  );
};

export default Survey;
